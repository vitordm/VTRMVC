<?php

class AppModel extends \VTRMVC\Core\Model
{

}