<?php

class HomeModel extends AppModel
{

}